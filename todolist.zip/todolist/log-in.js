function validateLogin(user, pass) { 
   
    if (user == "") {
      alert("Username must be filled out");
      document.forms["signin"]["user"].focus();
      return false;
    }

    if (pass == "") {
       alert("Password must be filled out");
       document.forms["signin"]["pass"].focus();
      return false;
    }    

 return false;
}
 

function chkLogin(callback) { 

      var emailid = document.forms["signin"]["emailid"].value;

      var passwd = document.forms["signin"]["passwd"].value;

      callback(emailid,passwd); 

      if(emailid == "admin" && passwd =='12345') {  
           
        window.location = './todolist.html';
      } 
      
      else { 
        alert("username or password is incorrect");
         
      } 

    return false;
      
}

function chk(){
  var promise = new Promise(function(resolve,reject){
    var count =0;
    var chkbox =document.getElementsByClassName("chkbox");
    for(var i=0; i<chkbox.length;i++){
      if(chkbox[i].checked){
        console.log(i);
        count +=1;
      }
      if (count == 5){
        resolve("Congrats. 5 Tasks have been Successfully Completed");
      }
      else{
        reject("Not completed");
      }
    }
  });
}

promise
.then(function(s){alert(s);})
.catch(function(e){console.log(e);});