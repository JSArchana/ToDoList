function validateLogin(user, pass) { 
   
    if (user == "") {
      alert("Username must be filled out");
      document.forms["signin"]["user"].focus();
      return false;
    }

    if (pass == "") {
       alert("Password must be filled out");
       document.forms["signin"]["pass"].focus();
      return false;
    }    

 return false;
}
 

function chkLogin(callback) { 

      var emailid = document.forms["signin"]["emailid"].value;

      var passwd = document.forms["signin"]["passwd"].value;

      callback(emailid,passwd); 

      if(emailid == "admin" && passwd =='12345') {  
        alert("login successful!");   
        window.location = './todolist.html';
      } 
      
      else { 
        alert("username or password is incorrect");
         
      } 

    return false;
      
}