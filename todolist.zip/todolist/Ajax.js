function ajax() {

    let requestURL = "https://jsonpldaceholder.typicode.com/todos/1";
    var xhttp = new XMLHttpRequest(); 

    xhttp.onreadystatechange  = function() {
        if(this.readyState == 4 && this.status == 200){   
            var response = JSON.parse(this.responseText);
            var list = response;
            var output = "";
            for (var i=0; i<list.length;i++){
              output += "<tr> <td>"+ list[i].userId+"</td> <td>"+
                          list[i].id +"</td> <td>"+
                          list[i].title +"</td> <td>" ;
              if(list[i].completed == false) {
                output += "Pending" +"</td> <td>" ;
                output += "<input type = 'checkbox' class ='chkbox' onchange = 'chk()'>"+"</td> </tr>" ;
              }
              else {
                output += "Completed" +"</td> <td>" ;
                 output += " </td> </tr>" ;
              }
            }
            document.getElementById("demo").innerHTML = output;
       }
    };


    xhttp.open("GET",requestURL,true);

    xhttp.send();

}
